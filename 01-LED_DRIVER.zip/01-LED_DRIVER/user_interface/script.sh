#!/bin/sh
# para executar o script execute o comando seguinte: 
# sudo bash script.sh
function moduleExist(){
	MODULE="$1"
	if lsmod | grep "$MODULE" &> /dev/null ; then
			return 0
	else
			return 1
	fi
}

if moduleExist "led_driver"; then
	rmmod led_driver
fi

make clean
make all
insmod led_driver.ko 
chmod 666 /dev/led_driver
#dmesg
python led_driver.py