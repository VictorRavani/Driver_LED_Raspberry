#!/usr/bin/python3
# -*- coding: UTF-8 -*-
import os, sys
from time import sleep

class Leddriver:
	#Construtor;
	def __init__(self):
		# O driver está acessível?
		if os.access('/dev/led_driver', os.R_OK) != True:
			print("error na abertura do driver");
			exit(1);

	#Leitura do driver;
	def read(self):
		f= open ('/dev/led_driver','r');
		value = f.read(1);
		f.close();
		return value;
        
    #Escrita do driver;    
	def write(self, value):
		f= open ('/dev/led_driver','w');
		f.write(value);
		f.close();
  
led = Leddriver();

toggle = 0;
for x in range(6):
    led.write(str(toggle%2));
    toggle +=1;
    sleep(1);
print(led.read());