#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/uaccess.h>
#include <linux/gpio.h>

/*  Informações sobre o Device Driver */
MODULE_LICENSE("GPL");
MODULE_AUTHOR("Fernando Simplicio");
MODULE_DESCRIPTION("Driver Linux para Controle de Leds");
MODULE_VERSION("1.0.0");

/* Variables for device and device class */
static dev_t led_device_nr;
static struct class *led_driver_class;
static struct cdev led_driver_device;

#define DRIVER_NAME "led_driver"
#define DRIVER_CLASS "led_driver_class"

/**
 * Define qual a GPIO que será utilizada para o controle do Led;
 */
#define GPIO_21 (21)

/**
 * Esta função é chamada quando o driver é carregado internamente no Kernel;
 */
static int __init led_module_init(void); 

/**
 * Esta função é chamada quando o driver é removido do Kernel;
 */
static void __exit led_module_exit(void); 

/**
 * Esta função é chamada quando o arquivo é aberto;
 */
static int led_driver_open(struct inode *device_file, struct file *instance);

/**
 * Esta função é chamada quando o arquivo é fechado;
 */
static int led_driver_close(struct inode *device_file, struct file *instance);

/**
 * Realiza a escrita no driver;
 */
static ssize_t led_driver_write(struct file *File, const char *user_buffer, size_t count, loff_t *offs); 

/**
 * Realiza a leitura do driver;
 */
static ssize_t led_driver_read(struct file *File, char *user_buffer, size_t count, loff_t * offs); 

/**
 * Um dispositivo aberto é identificado internamente por uma estrutura de arquivos e o kernel usa a estrutura 
 * 'file_operations' para acessar * as funções do driver. 
 * A estrutura, definida em <linux/fs.h>, é um array de ponteiros de função.
 */
static struct file_operations fops = 
{
	.owner = THIS_MODULE,
	.open = 	led_driver_open,
	.release = 	led_driver_close,
	.read = 	led_driver_read,
	.write = 	led_driver_write
};

/**
 * Realiza a leitura do driver;
 */
static ssize_t led_driver_read(struct file *File, char *user_buffer, size_t count, loff_t * offs) 
{
	int to_copy, not_copied, delta;
	char tmp[3] = " \n";

	/**
	 * Tem acesso a quantidade de bytes que será lido
	 * do 'kernel space' para o 'user space'; 
	 */
	to_copy = min(count, sizeof(tmp));

	/**
	 * Realiza a leitura da GPIO 21;
	 */
	tmp[0] = gpio_get_value(GPIO_21) + '0';

	/**
	 * Os bytes recebidos do 'kernel space' são copiados para o 'user space';
	 * Retorna o número de bytes que não puderam ser copiados. Em caso de sucesso, isso será zero.
	 * Se alguns dados não puderem ser copiados, esta função preencherá os dados copiados 
	 * para o tamanho solicitado usando zero bytes.
	 */
	not_copied = copy_to_user(user_buffer, &tmp, to_copy);

	/**
	 * Retorna a diferença da quantidade de bytes que, por ventura não puderam
	 * ser copiados para o 'user space'. 
	 */
	delta = to_copy - not_copied;

	return delta;
}

/**
 * Realiza a escrita no driver;
 */
static ssize_t led_driver_write(struct file *File, const char *user_buffer, size_t count, loff_t *offs) 
{
	int to_copy, not_copied, delta;
	char value;

	/**
	 * Tem acesso a quantidade de bytes que sera lido
	 * do 'user space' para o 'kernel space'; 
	 */
	to_copy = min(count, sizeof(value));

	/**
	 * Os bytes recebidos do 'user space' são copiados para 'kernel space';
	 * Retorna o número de bytes que não puderam ser copiados. Em caso de sucesso, isso será zero.
	 * Se alguns dados não puderem ser copiados, esta função preencherá os dados copiados 
	 * para o tamanho solicitado usando zero bytes.
	 */
	not_copied = copy_from_user(&value, user_buffer, to_copy);

	/** Liga/Desliga Led */
	switch(value) {
		case '0':
			gpio_set_value(GPIO_21, 0);
			break;
		case '1':
			gpio_set_value(GPIO_21, 1);
			break;
		default:
			printk("Error.. Entrada Invalida!\n");
			break;
	}

	/**
	 * Retorna a diferença da quantidade de bytes que, por ventura não puderam
	 * ser copiados para o espaço do kernel. 
	 */
	delta = to_copy - not_copied;

	return delta;
}

/**
 * Esta função é chamada quando o arquivo é aberto;
 */
static int led_driver_open(struct inode *device_file, struct file *instance) 
{
	pr_info("led_driver_open!\n");
	return 0;
}

/**
 * Esta função é chamada quando o arquivo é fechado;
 */
static int led_driver_close(struct inode *device_file, struct file *instance) 
{
	pr_info("led_driver_close!\n");
	return 0;
}

/**
 * Esta função é chamada quando o driver é carregado internamente no Kernel;
 */
static int __init led_module_init(void) 
{
	pr_info("Ola Driver GPIO_LED!\n");

	/* Allocate a device nr */
	if( alloc_chrdev_region(&led_device_nr, 0, 1, DRIVER_NAME) < 0) {
		pr_info("Device nao pode ser alocado!\n");
		return -1;
	}
	pr_info("read_write - Device Nr. Major: %d, Minor: %d was registered!\n", 
									led_device_nr >> 20, led_device_nr && 0xfffff);

	/* Create device class */
	if((led_driver_class = class_create(THIS_MODULE, DRIVER_CLASS)) == NULL) {
		pr_info("Error na criacao da Classe do Device!\n");
		goto ClassError;
	}

	/* create device file */
	if(device_create(led_driver_class, NULL, led_device_nr, NULL, DRIVER_NAME) == NULL) {
		pr_info("Can not create device file!\n");
		goto FileError;
	}

	/* Initialize device file */
	cdev_init(&led_driver_device, &fops);

	/* Registra o dispositivo no kernel */
	if(cdev_add(&led_driver_device, led_device_nr, 1) == -1) {
		pr_info("Registering of device to kernel failed!\n");
		goto AddError;
	}

	/* GPIO 21 */
	if(gpio_request(GPIO_21, "GPIO_21")) {
		pr_info("Error.. gpio_request\n");
		goto GpioError;
	}

	/* Direção da GPIO 21 */
	if(gpio_direction_output(GPIO_21, 0)) {
		pr_info("Error.. gpio_direction_outpu!\n");
		goto GpioError;
	}

	return 0;
GpioError:
	gpio_free(GPIO_21);
AddError:
	device_destroy(led_driver_class, led_device_nr);
FileError:
	class_destroy(led_driver_class);
ClassError:
	unregister_chrdev_region(led_device_nr, 1);
	return -1;
}

/**
 * Esta função é chamada quando o driver é removido do Kernel;
 */
static void __exit led_module_exit (void) 
{
	gpio_free(GPIO_21);
	
	cdev_del(&led_driver_device);
	device_destroy(led_driver_class, led_device_nr);
	class_destroy(led_driver_class);
	unregister_chrdev_region(led_device_nr, 1);
	
	pr_info("bye\n");
}

module_init(led_module_init);
module_exit(led_module_exit);


